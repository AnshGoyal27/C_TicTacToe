#include <stdio.h>
#include <stdlib.h>

void printboard(char arr[3][3]);
void enterXO(char arr[3][3],char c,char p[20]);
int checkcondition(char arr[3][3],char c);
void compmoveO(char arr[3][3],int i);
void compmoveX(char arr[3][3],int i);
void gamecomp(int *a,char name1[20]);
void blockormakemove(char arr[3][3],char O,char X);

static int userwon=0,draw=0,compwon=0;
static int userpart=0;

int main(){
    char name1[20];
    printf("Enter your name player 1 ");
    fflush(stdin);
    gets(name1);
    printf("Enter \n1.To play first \n2.To go second \n");
    scanf("%d",&userpart);
    printf("\n");
    gamecomp(&userpart,name1);

return 0;
}



void printboard(char arr[3][3]){
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            printf("%c ",arr[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void enterXO(char arr[3][3],char c,char p[20]){
    int row;
    int column;
    printf("Entering for ");
    puts(p);
    do{
        printf("Enter row (1-3) ");
        scanf("%d",&row);
        printf("Enter column (1-3) ");
        scanf("%d",&column);
    }while(row>3 || row<1 || column>3 || column<1 || arr[row-1][column-1]!='-');
    arr[row-1][column-1]=c;
}

int checkcondition(char arr[3][3],char c){
    int k=0;
    int won=0;
    for(int i=0;i<3;i++){
        k=0;
        for(int j=0;j<3;j++){
            if(arr[i][j]==c){
                k++;
            }
            else{
                break;
            }
        }
        if(k==3){
            won=1;
            break;
        }
        else{}
    }
    if (won!=1){
        for(int i=0;i<3;i++){
        k=0;
        for(int j=0;j<3;j++){
            if(arr[j][i]==c){
                k++;
            }
            else{
                break;
            }
        }
        if(k==3){
            won=1;
            break;
        }
        else{}
        }    
        if(won!=1){
            if(arr[0][0]==c && arr[1][1]==c && arr[2][2]==c){
                won=1;
            }
            else if(arr[0][2]==c && arr[1][1]==c && arr[2][0]==c){
                won=1;
            }
        }
    }
    if(won==0){
        return 0;
    }
    else{
        return 1;
    }
}

void compmoveO(char arr[3][3],int i){
    if (i==1){
        if (arr[1][1]=='-'){
            arr[1][1]='O';
        }
        else{
            arr[0][0]='O';
        }
    }
    else if (i==3){
        if ((arr[0][0]=='X' && arr[2][2]=='X')){
            arr[1][0]='O';
        }
        else if( (arr[0][2]=='X' && arr[2][0]=='X')){
            arr[1][2]='O';
        }
        else if((arr[0][2]=='X' || arr[2][0]=='X' || arr[2][2]=='X') && arr[1][1]=='X'){
            if(arr[0][2]=='-'){
                arr[0][2]='O';
            }
            else if(arr[2][0]=='-'){
                arr[2][0]='O';
            }
            else if(arr[2][2]=='-'){
                arr[2][2]='O';
            }
        }
        else{
            blockormakemove(arr,'O','X');
            }
    }
    else{
        blockormakemove(arr,'O','X');
    }
}

void compmoveX(char arr[3][3],int i){
    if (i==0){
        arr[0][0]='X';
    }
    else{
        blockormakemove(arr,'X','O');
        }
}

void gamecomp(int *a,char name1[20]){
    char yorn,sameordiff;
    int winornot=0;
    int i=0;
    int row,column;
    char tictac[3][3]={'-','-','-','-','-','-','-','-','-'};
    printboard(tictac);

    if (*a==2){
        do{
            if(i%2!=0){
                enterXO(tictac,'O',name1);
                printboard(tictac);
                i++;
                winornot=checkcondition(tictac,'O');
                if(winornot==1){
                    printf("Won by ");
                    puts(name1);
                    userwon++;
                }
            }
            else{
                compmoveX(tictac,i);
                printboard(tictac);
                i++;
                winornot=checkcondition(tictac,'X');
                if(winornot==1){
                    printf("Won by Computer \n");
                    compwon++;
                }
            }
        }while(i<9 && winornot!=1);

        if(winornot!=1){
            printf("Draw");
            draw++;
        }

        *a=1;
    }
    else if (*a==1){
        do{
            if(i%2==0){
                enterXO(tictac,'X',name1);
                printboard(tictac);
                i++;
                winornot=checkcondition(tictac,'X');
                if(winornot==1){
                    printf("Won by ");
                    puts(name1);
                    userwon++;
                }
            }
            else{
                compmoveO(tictac,i);
                printboard(tictac);
                i++;
                winornot=checkcondition(tictac,'O');
                if(winornot==1){
                    printf("Won by Computer \n");
                    compwon++;
                }
            }
        }while(i<9 && winornot!=1);  

        if(winornot!=1){
            printf("Draw");
            draw++;
        } 

        *a=2;  
    }

    printf("Scores are \n");
    printf("%d games won by ",userwon);
    puts(name1);
    printf("%d games won by comp \n",compwon);
    printf("%d games ended in draw ",draw);

    printf("\nDo you want to play this mode again?? Y or N ");
        fflush(stdin);
        scanf("%c",&yorn);
        switch(yorn){
            case 'Y':
                printf("Wish to play with same or diff players? S or D ");
                fflush(stdin);
                scanf("%c",&sameordiff);
                switch(sameordiff){
                    case 'S':
                        gamecomp(a,name1);
                        break;
                    case 'D':
                        compwon=0;
                        userwon=0;
                        draw=0;
                        main();
                        break;
                }
                break;
            case 'N':
                exit(0);
        }    
}

void blockormakemove(char arr[3][3],char O,char X){
    int abcd,efgh;
    if(((arr[1][0]==O && arr[2][0]==O)||(arr[0][1]==O && arr[0][2]==O)||(arr[1][1]==O && arr[2][2]==O)) && arr[0][0]=='-'){
        arr[0][0]=O;
    }
    else if(((arr[0][0]==O && arr[0][2]==O)||(arr[1][1]==O && arr[2][1]==O)) && arr[0][1]=='-'){
        arr[0][1]=O;
    }
    else if(((arr[0][0]==O && arr[0][1]==O)||(arr[1][2]==O && arr[2][2]==O)||(arr[1][1]==O && arr[2][0]==O)) && arr[0][2]=='-'){
        arr[0][2]=O;
    }
    else if(((arr[0][0]==O && arr[2][0]==O)||(arr[1][1]==O && arr[1][2]==O)) && arr[1][0]=='-'){
        arr[1][0]=O;
    }
    else if(((arr[0][0]==O && arr[2][2]==O)||(arr[0][1]==O && arr[2][1]==O)||(arr[0][2]==O && arr[2][0]==O)||(arr[1][0]==O && arr[1][2]==O)) && arr[1][1]=='-'){
        arr[1][1]=O;
    }
    else if(((arr[0][2]==O && arr[2][2]==O)||(arr[1][0]==O && arr[1][1]==O)) && arr[1][2]=='-'){
        arr[1][2]=O;
    }
    else if(((arr[0][0]==O && arr[1][0]==O)||(arr[1][1]==O && arr[0][2]==O)||(arr[2][1]==O && arr[2][2]==O)) && arr[2][0]=='-'){
        arr[2][0]=O;
    }
    else if(((arr[0][1]==O && arr[1][1]==O)||(arr[2][2]==O && arr[2][0]==O)) && arr[2][1]=='-'){
        arr[2][1]=O;
    }
    else if(((arr[0][0]==O && arr[1][1]==O)||(arr[2][1]==O && arr[2][0]==O)||(arr[0][2]==O && arr[1][2]==O)) && arr[2][2]=='-'){
        arr[2][2]=O;
    }
    else if(((arr[1][0]==X && arr[2][0]==X)||(arr[0][1]==X && arr[0][2]==X)||(arr[1][1]==X && arr[2][2]==X)) && arr[0][0]=='-'){
        arr[0][0]=O;
    }
    else if(((arr[0][0]==X && arr[0][2]==X)||(arr[1][1]==X && arr[2][1]==X)) && arr[0][1]=='-'){
        arr[0][1]=O;
    }
    else if(((arr[0][0]==X && arr[0][1]==X)||(arr[1][2]==X && arr[2][2]==X)||(arr[1][1]==X && arr[2][0]==X)) && arr[0][2]=='-'){
        arr[0][2]=O;
    }
    else if(((arr[0][0]==X && arr[2][0]==X)||(arr[1][1]==X && arr[1][2]==X)) && arr[1][0]=='-'){
        arr[1][0]=O;
    }
    else if(((arr[0][0]==X && arr[2][2]==X)||(arr[0][1]==X && arr[2][1]==X)||(arr[0][2]==X&& arr[2][0]==X)||(arr[1][0]==X && arr[1][2]==X)) && arr[1][1]=='-'){
        arr[1][1]=O;
    }
    else if(((arr[0][2]==X && arr[2][2]==X)||(arr[1][0]==X && arr[1][1]==X)) && arr[1][2]=='-'){
        arr[1][2]=O;
    }
    else if(((arr[0][0]==X && arr[1][0]==X)||(arr[1][1]==X && arr[0][2]==X)||(arr[2][1]==X && arr[2][2]==X)) && arr[2][0]=='-'){
        arr[2][0]=O;
    }
    else if(((arr[0][1]==X && arr[1][1]==X)||(arr[2][2]==X && arr[2][0]==X)) && arr[2][1]=='-'){
        arr[2][1]=O;
    }
    else if(((arr[0][0]==X && arr[1][1]==X)||(arr[2][1]==X && arr[2][0]==X)||(arr[0][2]==X && arr[1][2]==X)) && arr[2][2]=='-'){
        arr[2][2]=O;
    }
    else{
        do{
            abcd=rand()%3;
            efgh=rand()%3;
        }while(arr[abcd][efgh]!='-');
        arr[abcd][efgh]=O;
    }
}

