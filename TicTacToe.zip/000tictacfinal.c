#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 

int main(){
    int gametype;
    while(1){
        printf("Enter \n1.User vs Computer \n2.User vs User \n3.EXIT \n");
        scanf("%d",&gametype);
        if(gametype==1){
            system("/Users/anishgoyal/Desktop/Program/project/000tictacsingle");
        }
        else if (gametype==2){
            system("/Users/anishgoyal/Desktop/Program/project/000tictacmulti");
        }
        else if(gametype==3){
            break;
        }
        else{
            
        }
    }
return 0;
}