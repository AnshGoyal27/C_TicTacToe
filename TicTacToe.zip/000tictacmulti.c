#include <stdio.h>
#include <stdlib.h>

void printboard(char arr[3][3]);
void enterXO(char arr[3][3],char c,char p[20]);
int checkcondition(char arr[3][3],char c);
void game(char name1[20],char name2[20],int *a,int *b);

static int win1=0;
static int win2=0;
static int draw=0;

int main(){
    char name1[20],name2[20];

    printf("Enter your name player 1 ");
    fflush(stdin);
    gets(name1);
    printf("Enter your name player 2 ");
    fflush(stdin);
    gets(name2);
    game(name1,name2,&win1,&win2);


return 0;
}

void printboard(char arr[3][3]){
    for(int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            printf("%c ",arr[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

void enterXO(char arr[3][3],char c,char p[20]){
    int row;
    int column;
    printf("Entering for ");
    puts(p);
    do{
        printf("Enter row (1-3) ");
        scanf("%d",&row);
        printf("Enter column (1-3) ");
        scanf("%d",&column);
    }while(row>3 || row<1 || column>3 || column<1 || arr[row-1][column-1]!='-');
    arr[row-1][column-1]=c;
}

int checkcondition(char arr[3][3],char c){
    int k=0;
    int won=0;
    for(int i=0;i<3;i++){
        k=0;
        for(int j=0;j<3;j++){
            if(arr[i][j]==c){
                k++;
            }
            else{
                break;
            }
        }
        if(k==3){
            won=1;
            break;
        }
        else{}
    }
    if (won!=1){
        for(int i=0;i<3;i++){
        k=0;
        for(int j=0;j<3;j++){
            if(arr[j][i]==c){
                k++;
            }
            else{
                break;
            }
        }
        if(k==3){
            won=1;
            break;
        }
        else{}
        }    
        if(won!=1){
            if(arr[0][0]==c && arr[1][1]==c && arr[2][2]==c){
                won=1;
            }
            else if(arr[0][2]==c && arr[1][1]==c && arr[2][0]==c){
                won=1;
            }
        }
    }
    if(won==0){
        return 0;
    }
    else{
        return 1;
    }
}

void game(char name1[20],char name2[20],int *a,int *b){
    printf("Starting the Game........... \n");
    int winornot=0;
    int i=0;
    int row,column;
    char yorn,sameordiff;
    char tictac[3][3]={'-','-','-','-','-','-','-','-','-'};
    printboard(tictac);
    do{
        if(i%2==0){
            enterXO(tictac,'X',name1);
            printboard(tictac);
            i++;
            winornot=checkcondition(tictac,'X');
            if(winornot==1){
                printf("Won by ");
                puts(name1);
                (*a)++;
            }
        }
        else{
            enterXO(tictac,'O',name2);
            printboard(tictac);
            i++;
            winornot=checkcondition(tictac,'O');
            if(winornot==1){
                printf("Won by ");
                puts(name2);
                (*b)++;
            }
        }
    }while(i<9 && winornot!=1);

    if(winornot!=1){
        printf("Draw");
        draw++;
    }

    printf("Scores are \n");
    printf("%d games won by ",*a);
    puts(name1);
    printf("%d games won by ",*b);
    puts(name2);
    printf("%d games ended in draw ",draw);
    
    printf("\nDo you want to play this mode again?? Y or N ");
        fflush(stdin);
        scanf("%c",&yorn);
        switch(yorn){
            case 'Y':
                printf("Wish to play with same or diff players? S or D ");
                fflush(stdin);
                scanf("%c",&sameordiff);
                switch(sameordiff){
                    case 'S':
                        game(name2,name1,&win2,&win1);
                        break;
                    case 'D':
                        win1=0;
                        win2=0;
                        draw=0;
                        main();
                        break;
                }
                break;
            case 'N':
                exit(0);
        }
}